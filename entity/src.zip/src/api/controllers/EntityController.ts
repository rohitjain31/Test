import { Body, HeaderParam, HttpCode, JsonController, Get, ContentType, Post, QueryParam, UseBefore } from 'routing-controllers';
import { Logger } from '../../lib/logger';
import { StatusCodes } from 'http-status-codes';
import { EntityService } from '../services/EntityService';
import { URCHeaderMiddleware } from '../customMiddleware/URCHeaderMiddleware';
import { BodyParserMiddleware } from '../customMiddleware/BodyParserMiddleware';
import * as fs from 'fs/promises';
import * as path from 'path';

@JsonController('/entity')
@UseBefore(BodyParserMiddleware)
export class EntityController {
  private log = new Logger(__filename);
  public constructor(private entityService: EntityService) { }

  @Post('/registration')
  @HttpCode(StatusCodes.CREATED)
  @UseBefore(URCHeaderMiddleware)
  public async RegisterEntity(
    @HeaderParam('Unique-Reference-Code') urc: string,
    @Body() requestBody: any
  ): Promise<any> {
    const logMessage = `EntityController, RegisterEntity, urc ${urc}`;
    this.log.info(logMessage);
    const headers = { urc };
    return this.entityService.RegisterEntity(requestBody, headers);
  }

  @Get('/fetch/categories')
  @HttpCode(StatusCodes.CREATED)
  @UseBefore(URCHeaderMiddleware)
  public async FetchAllCategories(
    @HeaderParam('Unique-Reference-Code') urc: string
  ): Promise<any> {
    const logMessage = `EntityController, FetchAllCategories, urc ${urc}`;
    this.log.info(logMessage);
    const headers = { urc };
    return this.entityService.FetchAllCategories(headers);
  }

  @Get('/email-verification')
  @ContentType('text/html')
  @HttpCode(StatusCodes.CREATED)
  public async EntityEmailVerification(
    @HeaderParam('Unique-Reference-Code') urc: string,
    @QueryParam('entityToken') entityToken: string
  ): Promise<any> {
    const logMessage = `EntityController, EntityEmailVerification, urc ${urc}`;
    this.log.info(logMessage);
    const headers = { urc };
    const response = await this.entityService.EntityEmailVerification(entityToken, headers);
    const filePath = path.join(__dirname, '..', '..', 'views', response ? 'email-verification-success.html' : 'email-verification-fail.html');
    const content = await fs.readFile(filePath, 'utf8');
    return content;
  }
}
