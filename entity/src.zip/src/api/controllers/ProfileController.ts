import { Body, Get, HeaderParam, HttpCode, JsonController, Post, Put, QueryParam, UseBefore } from 'routing-controllers';
import { Logger } from '../../lib/logger';
import { StatusCodes } from 'http-status-codes';
import { ProfileService } from '../services/ProfileService';
import { URCHeaderMiddleware } from '../customMiddleware/URCHeaderMiddleware';
import { BodyParserMiddleware } from '../customMiddleware/BodyParserMiddleware';
import { AuthorizationHeaderMiddleware } from '../customMiddleware/AuthorizationHeaderMiddleware';

@JsonController('/profile')
@UseBefore(BodyParserMiddleware, URCHeaderMiddleware, AuthorizationHeaderMiddleware)
export class ProfileController {
    private log = new Logger(__filename);
    public constructor(private profileService: ProfileService) { }

    @Get('/fetch/entity')
    @HttpCode(StatusCodes.OK)
    public async FetchEntityData(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @QueryParam('entityId') entityId: string,
        @Body() requestBody: any,
    ): Promise<any> {
        const logMessage = `ProfileController, FetchEntityData, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        return this.profileService.FetchEntityData(requestBody, entityId, headers);
    }

    @Put('/update/entity')
    @HttpCode(StatusCodes.CREATED)
    public async UpdateEntityData(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @QueryParam('entityId') entityId: string,
        @Body() requestBody: any,
    ): Promise<any> {
        const logMessage = `ProfileController, UpdateEntityData, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        return this.profileService.UpdateEntityData(requestBody, entityId, headers);
    }

    @Put('/deactivate/entity')
    @HttpCode(StatusCodes.CREATED)
    public async DeactivateEntityProfile(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @QueryParam('entityId') entityId: string,
        @Body() requestBody: any,
    ): Promise<any> {
        const logMessage = `ProfileController, DeactivateEntityProfile, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        return this.profileService.DeactivateEntityProfile(requestBody, entityId, headers);
    }

    @Post('/add/category')
    @HttpCode(StatusCodes.CREATED)
    public async AddCategory(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @Body() requestBody: any,
        @QueryParam('entityId') entityId: string,
    ): Promise<any> {
        const logMessage = `ProfileController, AddCategory, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        return this.profileService.AddCategory(requestBody, entityId, headers);
    }

    @Get('/fetch/categories')
    @HttpCode(StatusCodes.CREATED)
    public async FetchAllCategories(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @QueryParam('entityId') entityId: string,
        @Body() requestBody: any,
    ): Promise<any> {
        const logMessage = `ProfileController, FetchAllCategories, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        return this.profileService.FetchEntityData(requestBody, entityId, headers);
    }
}
