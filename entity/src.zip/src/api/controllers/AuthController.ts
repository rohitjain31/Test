import express from 'express';
import { Body, HeaderParam, HttpCode, JsonController, Post, Res, UseBefore } from 'routing-controllers';
import { Logger } from '../../lib/logger';
import { StatusCodes } from 'http-status-codes';
import { AuthService } from '../services/AuthService';
import { URCHeaderMiddleware } from '../customMiddleware/URCHeaderMiddleware';
import { BodyParserMiddleware } from '../customMiddleware/BodyParserMiddleware';

@JsonController('/auth')
@UseBefore(BodyParserMiddleware, URCHeaderMiddleware)
export class AuthController {
    private log = new Logger(__filename);
    public constructor(private authService: AuthService) { }

    @Post('/entity/login')
    @HttpCode(StatusCodes.CREATED)
    public async EntityLogin(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @Body() requestBody: any,
        @Res() res: express.Response
    ): Promise<any> {
        const logMessage = `AuthController, EntityLogin, urc ${urc}`;
        this.log.info(logMessage);
        const headers = { urc };
        const data = await this.authService.EntityLogin(requestBody, headers);
        res.setHeader('Access-Control-Expose-Headers', 'Auth-Token');
        res.setHeader('Auth-Token', data?.token);
        return res.status(StatusCodes.CREATED).json({
            entityId: data.entityId
        });
    }

    @Post('/entity/logout')
    @HttpCode(StatusCodes.CREATED)
    public async EntityLogOut(
        @HeaderParam('Unique-Reference-Code') urc: string,
        @Res() res: express.Response
    ): Promise<any> {
        const logMessage = `AuthController, EntityLogOut, urc ${urc}`;
        this.log.info(logMessage);
        res.setHeader('Access-Control-Expose-Headers', 'Auth-Token');
        res.setHeader('Auth-Token', '');
        return res.status(StatusCodes.CREATED).send({});
    }
}
