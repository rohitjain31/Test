import { Document } from 'mongoose';

export interface IProcessedMessage extends Document {
  messageId: string;
  timestamp: Date;
}
