import mongoose, { Document } from 'mongoose';

export interface INotification extends Document {
  userId: mongoose.Types.ObjectId;
  emailType: string;
  status: 'Pending' | 'Sent' | 'Failed';
  sentAt?: Date;
  contentId: mongoose.Types.ObjectId;
}
