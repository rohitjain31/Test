import { Document } from 'mongoose';

export interface IEmailTemplate extends Document {
  templateName: string;
  subject: string;
  bodyHTML: string;
  bodyText: string;
  type: string;
}
