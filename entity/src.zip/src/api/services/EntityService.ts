import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';
import { isArray } from 'class-validator';
import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { isEmptyOrNull } from '../../lib/env';
import { Entity } from '../models/Entity';
import { HelperService } from './HelperService';
import { env } from '../../env';
import { Category } from '../models/MasterData/Category';
import { CategoryStatus } from '../models/enums/CategoryStatus';

@Service()
export class EntityService {
  private log = new Logger(__filename);
  public constructor(private helperService: HelperService) { }

  public async RegisterEntity(requestData: any, headers: any): Promise<any> {
    const { urc } = headers;
    const logMessage = `EntityService, RegisterSuperadmin, urc ${urc}`;
    this.log.info(logMessage);
    try {

      const isEntityExist = await Entity.findOne({ email: requestData.email });

      if (!isEmptyOrNull(isEntityExist)) {
        this.log.info(`${logMessage}, Entity already exist with email ${requestData.email}`);
        throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EntityAlreadyExist);
      }

      const entityId = uuidv4();
      const aggregatorId = uuidv4();
      const newEntity = new Entity({
        businessName: requestData.businessName,
        licenseNumber: requestData.licenseNumber,
        description: requestData.description,
        entityId,
        aggregatorId,
        email: requestData.email,
        contactInfo: { ...requestData.contactInfo },
        password: requestData.password,
        categories: requestData.categories || [],
        socialMediaLinks: requestData.socialMediaLinks || [],
        images: requestData.images || [],
      });
      await newEntity.save();
      this.log.info(`${logMessage}, Entity registered successfully`);

      const Payload = {
        entityId: { isEncryptionRequired: true, value: entityId },
        email: { isEncryptionRequired: true, value: requestData.email }
      };
      const encryptedKeyForDeepLink = await this.helperService.EncryptDataAndGenerateToken(
        Payload, env.jwt.emailDeepLinkSecret, `${env.jwt.emailDeepLinkExpiresIn}h`, env.constants.base64EncryptionKey, headers
      );
      const emailVerificationLink = `${env.emailVerification.baseurl}/${env.emailVerification.path}?entityToken=${encryptedKeyForDeepLink}`;
      // Send email for verification with email verification link
      // Call Notification service via event

      return { success: 'ok', emailVerificationLink };
    } catch (error: any) {
      this.log.info(`${logMessage}, Error in RegisterEntity`, error);
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
    }
  }

  public async FetchAllCategories(headers: any): Promise<any> {
    const { urc } = headers;
    const logMessage = `EntityService, FetchAllCategories, urc ${urc}`;
    this.log.info(logMessage);
    try {
      const result = await Category.find({ status: CategoryStatus.ACTIVE });
      const categories = isArray(result) ? result.map(doc => {
        return { type: doc.name, id: doc._id };
      }) : [];

      return { data: categories };
    } catch (error: any) {
      this.log.info(`${logMessage}, Error in FetchAllCategories`, { error });
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
    }
  }

  public async EntityEmailVerification(entityToken: any, headers: any): Promise<any> {
    const { urc } = headers;
    const logMessage = `EntityService, EntityEmailVerification, urc ${urc}`;
    this.log.info(logMessage);
    try {
      const validatedData = await this.helperService.DecryptTokenAndValidateData(
        entityToken, env.jwt.emailDeepLinkSecret, env.constants.base64EncryptionKey, headers
      );

      const { entityId, email } = validatedData || { entityId: '', email: '' };
      const isEntityExist = await Entity.findOne({ email, entityId });

      if (isEmptyOrNull(isEntityExist)) {
        this.log.info(`${logMessage}, Entity does not exist with ${email} or ${entityId}`);
        throw new CredError(HTTPCODES.BAD_REQUEST, CODES.NotAuthorized);
      }

      isEntityExist.isEmailVerified = true;
      await isEntityExist.save();
      this.log.info(`${logMessage}, Entity email verification is updated successfully`);

      return true;
    } catch (error: any) {
      this.log.info(`${logMessage}, Error in EntityEmailVerification`, { error });
      return false;
    }
  }
}
