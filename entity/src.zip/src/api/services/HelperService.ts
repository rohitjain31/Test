import { Service } from 'typedi';
import { Logger } from '../../lib/logger';
import { JWTSign, encrypt, JWTDecode, getDataFromValidatedToken } from '../../lib/env';
import { env } from '../../env';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';

@Service()
export class HelperService {
  private log = new Logger(__filename);
  public constructor() { }

  public EncryptDataAndGenerateToken(tokenPayload: any, secret: string, expiresIn: string, encryptionKey: string, headers: any): any {
    const { urc } = headers;
    const logMessage = `HelperService, EncryptDataAndGenerateToken, urc ${urc}`;
    this.log.info(logMessage);
    try {
      for (const key in tokenPayload) {
        if (tokenPayload[key].isEncryptionRequired) {
          tokenPayload[key].value = encrypt(tokenPayload[key].value, encryptionKey, env.constants.aesIVBase64);
        }
      }
      return JWTSign(tokenPayload, secret, expiresIn);
    } catch (error: any) {
      this.log.info(`${logMessage}, Error while EncryptDataAndGenerateToken`, { error });
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.AuthTokenError);
    }
  }

  public DecryptTokenAndValidateData(token: string, secret: string, encryptionKey: string, headers: any): any {
    const { urc } = headers;
    const logMessage = `HelperService, DecryptTokenAndValidateData, urc ${urc}`;
    this.log.info(logMessage);
    try {
      const validatedToken = JWTDecode(token, secret);
      if (validatedToken?.error) {
        this.log.info(`${logMessage}, Token is not validated`);
        throw new CredError(HTTPCODES.BAD_REQUEST, CODES.NotAuthorized);
      }

      const validatedData: any = getDataFromValidatedToken(validatedToken, encryptionKey, env.constants.aesIVBase64);
      return validatedData;
    } catch (error: any) {
      this.log.info(`${logMessage}, Error while DecryptTokenAndValidateData`, { error });
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.AuthTokenError);
    }
  }
}
