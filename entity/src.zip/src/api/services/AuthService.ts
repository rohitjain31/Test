import { Service } from 'typedi';
import { env } from '../../env';
import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { HelperService } from './HelperService';
import { Entity } from '../models/Entity';
import { isEmptyOrNull } from '../../lib/env';

@Service()
export class AuthService {
    private log = new Logger(__filename);
    public constructor(private helperService: HelperService) { }

    public async EntityLogin(requestData: any, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `AuthService, EntityLogin, urc ${urc}`;
        this.log.info(logMessage);
        try {
            const entityData: any = await Entity.findOne({ email: requestData.email });
            if (isEmptyOrNull(entityData)) {
                this.log.info(`${logMessage}, Entity details are not found`);
                throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EntitynotFound);
            }

            const isMatch = await entityData.comparePassword(requestData.password);
            if (!isMatch) {
                this.log.info(`${logMessage}, Incorrect passsword`);
                throw new CredError(HTTPCODES.BAD_REQUEST, CODES.IncorrectPassword);
            }

            const jwtTokenPayload = {
                entityId: { isEncryptionRequired: true, value: entityData.entityId },
                email: { isEncryptionRequired: true, value: requestData.email }
            };
            const token = await this.helperService.EncryptDataAndGenerateToken(
                jwtTokenPayload, env.jwt.entitySecret, `${env.jwt.entityExpiresIn}m`, env.constants.base64EncryptionKey, headers
            );
            this.log.info(`${logMessage}, Entity is logged in successfully`);

            return { token, entityId: entityData.entityId };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in EntityLogin`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }
}
