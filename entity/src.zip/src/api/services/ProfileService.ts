import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { isEmptyOrNull } from '../../lib/env';
import { Entity } from '../models/Entity';
import { Category } from '../models/MasterData/Category';
import { isArray } from 'class-validator';
import { HelperService } from './HelperService';
import { env } from '../../env';
import { CategoryStatus } from '../models/enums/CategoryStatus';
import { EntityStatus } from '../models/enums/EntityStatus';

@Service()
export class ProfileService {
    private log = new Logger(__filename);
    public constructor(private helperService: HelperService) { }

    public async FetchEntityData(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, FetchEntityData, urc ${urc}`;
        this.log.info(logMessage);
        try {
            const data = await this.ValidateTokenAndData(requestData, entityId, headers);
            return { data };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in FetchEntityData`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }

    public async UpdateEntityData(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, UpdateEntityData, urc ${urc}`;
        this.log.info(logMessage);
        try {
            await this.ValidateTokenAndData(requestData, entityId, headers);
            await Entity.updateOne({ entityId }, {
                businessName: requestData.businessName,
                description: requestData.description,
                contactInfo: { ...requestData.contactInfo },
            });

            return { success: 'ok' };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in UpdateEntityData`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }

    public async DeactivateEntityProfile(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, DeactivateEntityProfile, urc ${urc}`;
        this.log.info(logMessage);
        try {
            await this.ValidateTokenAndData(requestData, entityId, headers);
            await Entity.updateOne({ entityId }, { status: EntityStatus.INACTIVE });

            return { success: 'ok' };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in DeactivateEntityProfile`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }

    public async FetchAllCategories(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, FetchAllCategories, urc ${urc}`;
        this.log.info(logMessage);
        try {
            const entityData = await this.ValidateTokenAndData(requestData, entityId, headers);

            const result = await Category.find({ status: CategoryStatus.ACTIVE, businessType: entityData.businessType });
            const categories = isArray(result) ? result.map(doc => doc.toObject()) : [];

            return { data: categories };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in FetchAllCategories`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }

    public async AddCategory(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, AddCategory, urc ${urc}`;
        this.log.info(logMessage);
        try {
            const entityData = await this.ValidateTokenAndData(requestData, entityId, headers);

            const categoryData = await Category.findOne({ name: new RegExp(`^${requestData.name}`, 'i'), businessType: entityData.businessType });
            if (!isEmptyOrNull(categoryData)) {
                this.log.info(`${logMessage}, category ${requestData.name} already exist with status ${categoryData.status} for business type ${entityData.businessType}`);
                throw new CredError(HTTPCODES.BAD_REQUEST, CODES.CategoryAlreadyExist);
            }

            const categoryId = uuidv4();
            const newCategory = new Category({
                categoryId,
                name: requestData.name?.trim(),
                description: requestData.description?.trim(),
                businessType: entityData.businessType,
                addedBy: entityId,
            });
            await newCategory.save();
            this.log.info(`${logMessage}, New category is added by ${entityId}`);

            return { success: 'ok' };
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in AddCategory`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }

    private async ValidateTokenAndData(requestData: any, entityId: string, headers: any): Promise<any> {
        const { urc } = headers;
        const logMessage = `ProfileService, ValidateTokenAndData, urc ${urc}`;
        this.log.info(logMessage);
        try {
            const validatedData: any = await this.helperService.DecryptTokenAndValidateData(requestData?.authToken, env.jwt.entitySecret, env.constants.base64EncryptionKey, headers);
            if (entityId !== validatedData?.entityId) {
                this.log.info(`${logMessage}, Entity id ${entityId} is not matched with token entity id ${validatedData?.entityId}`);
                throw new CredError(HTTPCODES.BAD_REQUEST, CODES.InvalidEntityId);
            }

            const result = await Entity.findOne({ entityId });
            const entityData: any = isEmptyOrNull(result) ? {} : result.toObject();

            if (isEmptyOrNull(entityData)) {
                this.log.info(`${logMessage}, Entity details are not found`);
                throw new CredError(HTTPCODES.BAD_REQUEST, CODES.InvalidEntityId);
            }

            return entityData;
        } catch (error: any) {
            this.log.info(`${logMessage}, Error in ValidateTokenAndData`, { error });
            throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
        }
    }
}
