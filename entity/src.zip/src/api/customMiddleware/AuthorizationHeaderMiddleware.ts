import * as express from 'express';
import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';
import { Container } from 'typedi';

import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { isArray } from 'class-validator';

@Middleware({ type: 'before' })
export class AuthorizationHeaderMiddleware implements ExpressMiddlewareInterface {
  private log = new Logger(__filename);
  public use(req: express.Request, res: express.Response, next: express.NextFunction): any {
    const logMessage = 'AuthorizationHeaderMiddleware :: use';
    const authorizeHeader = (req.header('Authorization') || '').trim();
    if (!authorizeHeader) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EmptyAuthorization);
    }
    if (authorizeHeader.indexOf('Bearer') < 0) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.NotAuthorized);
    }

    const tempVar = authorizeHeader.split(' ');
    const authToken = isArray(tempVar) && tempVar.length > 1 ? tempVar[1] : '';
    if (!authToken) {
      this.log.info(`${logMessage}, Authorization token is empty`);
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EmptyAuthorization);
    }

    req.body = { ...req.body, authToken };

    Container.set('requestHeaders', req.headers);
    next();
  }
}
