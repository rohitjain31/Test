import { CODES } from './errorCodeConstants';

const errors: { [key: string]: { code: string; message?: string; description?: string } } = {
  [CODES.InvalidBody]: {
    code: 'GLOBAL.BODY_INVALID',
    message: 'Invalid Request Parameters',
    description: 'Invalid Request Parameters'
  },
  [CODES.EmptyAuthorization]: {
    code: 'GLOBAL.EMPTY.AUTHORIZATION_TOKEN',
    message: 'Authorization token is empty',
    description: 'Authorization token is empty'
  },
  [CODES.NotAuthorized]: {
    code: 'GLOBAL.NOT_AUTHORIZED',
    message: 'User is not authorized',
    description: 'User is not authorized'
  },
  [CODES.EmptyContentType]: {
    code: 'GLOBAL.EMPTY.CONTENT_TYPE',
    message: 'Content type is empty',
    description: 'Content type is empty'
  },
  [CODES.InvalidContentType]: {
    code: 'GLOBAL.INVALID.CONTENT_TYPE',
    message: 'Content type is invalid',
    description: 'Content type is invalid'
  },
  [CODES.EmptyURC]: {
    code: 'GLOBAL.EMPTY.URC',
    message: 'Unique reference code is empty',
    description: 'Unique reference code is empty'
  },
  [CODES.InvalidURC]: {
    code: 'GLOBAL.INVALID.URC',
    message: 'Unique reference code is invalid',
    description: 'Unique reference code is invalid'
  },
  [CODES.GenericErrorMessage]: {
    code: 'GLOBAL.INTERVAL_SERVER_ERROR',
    message: 'There is some issue. Please contact administrator',
    description: 'There is some issue. Please contact administrator'
  },
  [CODES.ProductNotFound]: {
    code: 'GLOBAL.NOT_FOUND.PRODUCT',
    message: 'Product not found',
    description: 'Product not found'
  },
  [CODES.DocumentAlreadyMapped]: {
    code: 'GLOBAL.MAPPED.DOCUMENT_TYPE',
    message: 'Document type is already mapped',
    description: 'Document type is already mapped'
  },
  [CODES.IncorrectPassword]: {
    code: 'GLOBAL.INCORRECT.PASSWORD',
    message: 'Password is incorrect',
    description: 'Password is incorrect'
  },
  [CODES.InvalidRegistrationHeader]: {
    code: 'GLOBAL.INVALID.REGISTRATION_HEADER',
    message: 'Registration header is invalid',
    description: 'Registration header is invalid'
  },
  [CODES.AuthTokenError]: {
    code: 'GLOBAL.ERROR.AUTH_TOKEN',
    message: 'Error in generating auth token',
    description: 'Error in generating auth token'
  },
  [CODES.InvalidJWTToken]: {
    code: 'GLOBAL.INVALID.AUTH_TOKEN',
    message: 'Auth token is invalid',
    description: 'Auth token is invalid'
  },
  [CODES.EmptyAuthToken]: {
    code: 'GLOBAL.EMPTY.AUTH_TOKEN',
    message: 'Auth token is empty',
    description: 'Auth token is empty'
  },
  [CODES.CustomerNotFound]: {
    code: 'GLOBAL.NOT_FOUND.CUSTOMER',
    message: 'Customer details are not found',
    description: 'Customer details are not found'
  },
  [CODES.InvalidExternalEntityKey]: {
    code: 'GLOBAL.INVALID.EXTERNAL_KEY',
    message: 'External entity key is invalid',
    description: 'External entity key is invalid'
  },
  [CODES.EntityAlreadyExist]: {
    code: 'GLOBAL.EXIST.ENTITY',
    message: 'Entity already exist',
    description: 'Entity already exist'
  },
  [CODES.InvalidEntityId]: {
    code: 'GLOBAL.INVALID.ENTITY-ID',
    message: 'Entity details are not found',
    description: 'Entity details are not found'
  },
  [CODES.CategoryAlreadyExist]: {
    code: 'GLOBAL.EXIST.CATEGORY',
    message: 'Category already exist',
    description: 'Category already exist'
  },
  [CODES.InvalidCategoryId]: {
    code: 'GLOBAL.INVALID.CATEGORY-ID',
    message: 'Category details are not found',
    description: 'Category details are not found'
  },
  [CODES.InvalidPrices]: {
    code: 'GLOBAL.INVALID.PRICES',
    message: 'Invalid maximum, minimum or current prices are provided',
    description: 'Invalid maximum, minimum or current prices are provided'
  },
  [CODES.EntitynotFound]: {
    code: 'GLOBAL.NOT_FOUND.ENTITY',
    message: 'Entity is not found',
    description: 'Entity is not found'
  },
};

export const constantErrors = Object.assign({}, errors);
