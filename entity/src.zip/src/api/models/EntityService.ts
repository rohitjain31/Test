import mongoose from 'mongoose';

const entityServiceSchema = new mongoose.Schema({
    entity: { type: mongoose.Schema.Types.ObjectId, ref: 'Entity' },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
    subCategory: { type: mongoose.Schema.Types.ObjectId, ref: 'SubCategory' },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
    availability: [{ type: mongoose.Schema.Types.ObjectId, ref: 'TimeSlot' }]
});

module.exports = mongoose.model('EntityService', entityServiceSchema);