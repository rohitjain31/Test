import mongoose from 'mongoose';
import { EntityStatus } from './enums/EntityStatus';
const bcrypt = require('bcryptjs');

const entitySchema = new mongoose.Schema(
  {
    businessName: {
      type: String,
      required: true,
      minLength: 1,
      maxLength: 50
    },
    licenseNumber: {
      type: String,
      required: true,
      minLength: 1,
      maxLength: 40
    },
    description: {
      type: String,
      minLength: 0,
      maxLength: 100
    },
    entityId: {
      type: String,
      unique: true
    },
    aggregatorId: {
      type: String,
      unique: true
    },
    email: {
      type: String,
      unique: true,
      minLength: 3,
      maxLength: 40
    },
    contactInfo: {
      phone: String,
      address: String,
      city: String,
      state: String,
      country: String,
      zip: String,
    },
    isEmailVerified: { type: Boolean, default: false },
    isActive: Boolean,
    password: {
      type: String,
      required: true,
      minLength: 3,
      maxLength: 100
    },
    status: {
      type: String,
      enum: EntityStatus,
      default: EntityStatus.PENDING_VERIFICATION,
    },
    categories: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Category' }],
    socialMediaLinks: [String], // TODO : implement later
    images: [String], // TODO : implement later
  },
  { timestamps: true }
);

entitySchema.pre('save', async function (next) {
  const user = this;
  if (!user.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(user.password, salt);

    user.isActive = true;
    user.password = hashedPassword;
    next();
  } catch (error: any) {
    next(error);
  }
});

entitySchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

export const Entity = mongoose.model('Entity', entitySchema);
