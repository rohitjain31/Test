import mongoose from 'mongoose';
import { CategoryStatus } from '../enums/CategoryStatus';

// Master Collection
const categorySchema = new mongoose.Schema(
  {
    CategoryId: String,
    name: {
      type: String,
      minLength: 1,
      maxLength: 20
    },
    description: {
      type: String,
      minLength: 0,
      maxLength: 100
    },
    status: {
      type: String,
      enum: CategoryStatus,
      default: CategoryStatus.PENDING_VERIFICATION,
    },
    addedBy: String,
    verifiedBy: String,
  },
  { timestamps: true }
);

export const Category = mongoose.model('Category', categorySchema);
