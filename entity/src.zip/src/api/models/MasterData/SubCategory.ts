import mongoose from 'mongoose';
import { SubCategoryStatus } from '../enums/SubCategoryStatus';

// Master collection
const subCategorySchema = new mongoose.Schema(
  {
    categoryId: String,
    SubCategoryId: String,
    name: {
      type: String,
      minLength: 1,
      maxLength: 20
    },
    description: {
      type: String,
      minLength: 0,
      maxLength: 100
    },
    status: {
      type: String,
      enum: SubCategoryStatus,
      default: SubCategoryStatus.PENDING_VERIFICATION,
    },
    addedBy: String,
    verifiedBy: String,
  },
  { timestamps: true }
);

export const SubCategory = mongoose.model('SubCategory', subCategorySchema);
