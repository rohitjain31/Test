import mongoose from 'mongoose';
import { ServiceStatus } from '../enums/ServiceStatus';

// Master collection
const serviceSchema = new mongoose.Schema(
    {
        categoryId: String,
        subCategoryId: String,
        serviceId: String,
        name: {
            type: String,
            minLength: 1,
            maxLength: 20
        },
        description: {
            type: String,
            minLength: 0,
            maxLength: 100
        },
        status: {
            type: String,
            enum: ServiceStatus,
            default: ServiceStatus.PENDING_VERIFICATION,
        },
        addedBy: String,
        verifiedBy: String,
    },
    { timestamps: true }
);

export const Service = mongoose.model('Service', serviceSchema);
