import mongoose from 'mongoose';

const entityReviewSchema = new mongoose.Schema({
    entity: { type: mongoose.Schema.Types.ObjectId, ref: 'Entity', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    rating: { type: Number, required: true },
    review_text: { type: String },
    created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('EntityReview', entityReviewSchema);