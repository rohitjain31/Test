import mongoose from 'mongoose';

const entityCategorySchema = new mongoose.Schema(
  {
    entity: { type: mongoose.Schema.Types.ObjectId, ref: 'Entity' },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
    subCategories: [{ type: mongoose.Schema.Types.ObjectId, ref: 'SubCategory' }],
    services: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Service' }],
  },
  { timestamps: true }
);

export const EntityCategory = mongoose.model('EntityCategory', entityCategorySchema);
