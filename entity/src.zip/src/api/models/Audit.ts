import mongoose from 'mongoose';

const auditSchema = new mongoose.Schema(
    {
        action: String,
        entityId: String,
    },
    { timestamps: true }
);

export const Audit = mongoose.model('Audit', auditSchema);
