import mongoose from 'mongoose';

const entitySlotSchema = new mongoose.Schema({
    entity: { type: mongoose.Schema.Types.ObjectId, ref: 'Entity', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'EntityService', required: true },
    start_time: { type: Date, required: true },
    end_time: { type: Date, required: true },
    availability: { type: Boolean, default: true },
    isActive: { type: Boolean, default: true },
    price: { type: Number, required: true },
    numberOfSlots: Number,
    bookingDetails: Object,
    source: String, // B2B or B2C
});

module.exports = mongoose.model('EntitySlot', entitySlotSchema);