import * as dotenv from 'dotenv';
import * as path from 'path';

import * as pkg from '../package.json';
import { getOsEnv, getOsPaths, getPaths, normalizePort, toBool } from './lib/env';

/**
 * Load .env file or for tests the .env.test file.
 */
dotenv.config({
  path: path.join(process.cwd(), `.env${process.env.NODE_ENV === 'test' ? '.test' : ''}`)
});

/**
 * Environment variables
 */
export const env = {
  node: process.env.NODE_ENV || 'development',
  isProduction: process.env.NODE_ENV === 'production',
  isTest: process.env.NODE_ENV === 'test',
  isDevelopment: process.env.NODE_ENV === 'development',
  constants: {
    registrationHeader: getOsEnv('REGISTRATION_HEADER') || 'Bearer 871634809126924',
    base64EncryptionKey: getOsEnv('BASE64_ENCRYPTION_KEY') || 'klyedassadsdsadawefdsf',
    aesIVBase64: getOsEnv('AES_IV_BASE64') || 'AAAAAAAAAAAAAAAAAAAAAA==',
    encryption: {
      algorithm: getOsEnv('ENCRYPTION_ALGORITHM') || 'aes-256-cbc',
      key: getOsEnv('BASE64_ENCRYPTION_KEY') || 'MzVjNWM0NmIxZTQ5YjA2MzZmM2JhODQ0NjI4ZDYwODQ=',
      iv: getOsEnv('BASE64_ENCRYPTION_IV') || 'Nzg5MjM0NzM4NzRmOWIwZA=='
    },
  },
  jwt: {
    secret: getOsEnv('JWT_SECRET'),
    expiresIn: getOsEnv('JWT_EXPIRESIN') || '2', // define in hours
  },
  app: {
    name: getOsEnv('APP_NAME') || (pkg as any).name,
    version: (pkg as any).version,
    description: (pkg as any).description,
    host: getOsEnv('APP_HOST') || 'localhost',
    schema: getOsEnv('APP_SCHEMA') || 'http',
    routePrefix: getOsEnv('APP_ROUTE_PREFIX') || '/appointee/admin/v1/api',
    port: normalizePort(process.env.PORT || getOsEnv('APP_PORT') || '3000'),
    banner: toBool(getOsEnv('APP_BANNER') || 'true'),
    dirs: {
      controllers: getOsPaths('CONTROLLERS') || getPaths(['src/api/controllers/**/*Controller.ts']),
      middlewares: getOsPaths('MIDDLEWARES') || getPaths(['src/api/middlewares/*Middleware.ts']),
      interceptors: getOsPaths('INTERCEPTORS') || getPaths(['src/api/interceptors/**/*Interceptor.ts']),
      resolvers: getOsPaths('RESOLVERS') || getPaths(['src/api/resolvers/**/*Resolver.ts'])
    }
  },
  log: {
    level: getOsEnv('LOG_LEVEL'),
    json: toBool(getOsEnv('LOG_JSON')),
    output: getOsEnv('LOG_OUTPUT')
  },
  db: {
    mongoURL: getOsEnv('MONGO_URL') || 'mongodb://127.0.0.1:27017/AppointmentDB'
  },
  monitor: {
    enabled: toBool(getOsEnv('MONITOR_ENABLED')),
    route: getOsEnv('MONITOR_ROUTE'),
    username: getOsEnv('MONITOR_USERNAME'),
    password: getOsEnv('MONITOR_PASSWORD')
  },
  errors: {
    errorPrefix: getOsEnv('ERROR_CODE_PREFIX') || 'APPOINTEE',
    default: {
      errorCode: getOsEnv('DEFAULT_ERROR_CODE') || 'GLOBAL.UNMAPPED-ERROR',
      errorMessage: getOsEnv('DEFAULT_ERROR_MSG') || 'Something went wrong, please try after sometime',
      errorDescription:
        getOsEnv('DEFAULT_ERROR_DESC') || 'Error is not mapped in the service, please check log for further info'
    }
  },
};
