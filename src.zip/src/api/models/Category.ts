import mongoose from 'mongoose';
import { CategoryStatus } from './enums/CategoryStatus';

const categorySchema = new mongoose.Schema(
    {
        categoryId: String,
        name: {
            type: String,
            minLength: 1,
            maxLength: 20
        },
        description: {
            type: String,
            minLength: 0,
            maxLength: 100
        },
        status: {
            type: String,
            enum: CategoryStatus,
            default: CategoryStatus.PENDING_VERIFICATION,
        },
        addedBy: String,
    },
    { timestamps: true }
);

export const Category = mongoose.model('Category', categorySchema);
