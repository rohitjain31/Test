import mongoose from 'mongoose';
import { ServiceStatus } from './enums/ServiceStatus';

const serviceSchema = new mongoose.Schema(
    {
        serviceId: String,
        name: {
            type: String,
            minLength: 1,
            maxLength: 20
        },
        description: {
            type: String,
            minLength: 0,
            maxLength: 100
        },
        status: {
            type: String,
            enum: ServiceStatus,
            default: ServiceStatus.PENDING_VERIFICATION,
        },
        addedBy: String,
        category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    },
    { timestamps: true }
);

export const Service = mongoose.model('Service', serviceSchema);
