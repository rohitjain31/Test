import { Service } from 'typedi';
import { Logger } from '../../lib/logger';
import { JWTSign, encrypt } from '../../lib/env';
import { env } from '../../env';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';

@Service()
export class HelperService {
  private log = new Logger(__filename);
  public constructor() { }

  public generateToken(tokenPayload: any, secret: string, expiresIn: string, headers: any): any {
    const { urc } = headers;
    const logMessage = `HelperService, generateToken, urc ${urc}`;
    this.log.info(logMessage);
    try {
      for (const key in tokenPayload) {
        if (tokenPayload[key].isEncryptionRequired) {
          tokenPayload[key].value = encrypt(
            tokenPayload[key].value,
            env.constants.base64EncryptionKey,
            env.constants.aesIVBase64
          );
        }
      }
      return JWTSign(tokenPayload, secret, expiresIn);
    } catch (error: any) {
      this.log.info(`${logMessage}, Error while generate jwt token`, { error });
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.AuthTokenError);
    }
  }
}
