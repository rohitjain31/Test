import { Service } from 'typedi';
import { env } from '../../env';
import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { Admin } from '../models/Admin';
import { HelperService } from './HelperService';

@Service()
export class AuthService {
  private log = new Logger(__filename);
  public constructor(private helperService: HelperService) { }

  public async LoginSuperadmin(requestData: any, headers: any): Promise<any> {
    const { urc } = headers;
    const logMessage = `AuthService, LoginSuperadmin, urc ${urc}`;
    this.log.info(logMessage);
    try {
      const user: any = await Admin.findOne({ username: requestData.username });
      const isMatch = await user.comparePassword(requestData.password);

      if (!isMatch) {
        this.log.info(`${logMessage}, Incorrect passsword`);
        throw new CredError(HTTPCODES.BAD_REQUEST, CODES.IncorrectPassword);
      }

      const jwtTokenPayload = {
        username: { isEncryptionRequired: true, value: requestData.username },
        uniqueId: { isEncryptionRequired: false, value: user.uniqueId }
      };
      const token = await this.helperService.generateToken(jwtTokenPayload, env.jwt.secret, `${env.jwt.expiresIn}h`, headers);
      this.log.info(`${logMessage}, Super user is logged in successfully`);

      return { token };
    } catch (error: any) {
      this.log.info(`${logMessage}, Error in login super admin`, { error });
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
    }
  }
}
