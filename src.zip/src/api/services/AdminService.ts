import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from '../../lib/logger';
import { Admin } from '../models/Admin';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';

@Service()
export class AdminService {
  private log = new Logger(__filename);
  public constructor() { }

  public async RegisterSuperadmin(requestData: any, headers: any): Promise<any> {
    const { urc } = headers;
    const logMessage = `AdminService, RegisterSuperadmin, urc ${urc}`;
    this.log.info(logMessage);
    try {
      const newAdmin = new Admin({
        username: requestData.username,
        password: requestData.password,
        uniqueId: uuidv4()
      });
      await newAdmin.save();
      this.log.info(`${logMessage}, Super user is registered successfully`);
      return { success: 'ok' };
    } catch (error: any) {
      this.log.info(`${logMessage}, Error in registering super admin`, { error });
      if (error?.code === 11000) {
        throw new CredError(HTTPCODES.BAD_REQUEST, CODES.DuplicateKeyError);
      }
      throw new CredError(error.HttpCode || HTTPCODES.BAD_REQUEST, error.code || CODES.GenericErrorMessage);
    }
  }
}
