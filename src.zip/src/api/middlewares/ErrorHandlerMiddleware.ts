import * as express from 'express';
import { StatusCodes } from 'http-status-codes';
import { ExpressErrorMiddlewareInterface, Middleware, HttpError } from 'routing-controllers';

import { env } from '../../env';
import { ErrorResponse } from '../errors/ErrorResponse';
import { Logger } from '../../lib/logger';

@Middleware({ type: 'after' })
export class ErrorHandlerMiddleware implements ExpressErrorMiddlewareInterface {
  public isProduction = env.isProduction;
  private log = new Logger(__filename);

  constructor() { }

  public error(error: HttpError, req: express.Request, res: express.Response, next: express.NextFunction): void {
    const logMessage = `ErrorHandlerMiddleware, error, urc: ${req.headers['Unique-Reference-Code']}`;
    this.log.info(`${logMessage}, method ${req.method}, url ${req.url}`);

    const errors = new ErrorResponse(error).get();
    res.status(error.httpCode || StatusCodes.BAD_REQUEST);
    res.json({ errors });

    next();
  }
}
