import { Body, HeaderParam, HttpCode, JsonController, Post, UseBefore } from 'routing-controllers';
import { Logger } from '../../lib/logger';
import { StatusCodes } from 'http-status-codes';
import { AdminService } from '../services/AdminService';
import { URCHeaderMiddleware } from '../customMiddleware/URCHeaderMiddleware';
import { RegistrationHeaderMiddleware } from '../customMiddleware/RegistrationHeaderMiddleware';
import { BodyParserMiddleware } from '../customMiddleware/BodyParserMiddleware';
import { AdminRegister } from './requests/AdminRegister'

@JsonController('/admin')
@UseBefore(BodyParserMiddleware, URCHeaderMiddleware)
export class AdminController {
  private log = new Logger(__filename);
  public constructor(private adminService: AdminService) { }

  @Post('/register')
  @HttpCode(StatusCodes.CREATED)
  @UseBefore(RegistrationHeaderMiddleware)
  public async RegisterSuperadmin(
    @HeaderParam('Unique-Reference-Code') urc: string,
    @Body() requestBody: AdminRegister
  ): Promise<any> {
    const logMessage = `AdminController, RegisterSuperadmin, urc ${urc}`;
    this.log.info(logMessage);
    const headers = { urc };
    return this.adminService.RegisterSuperadmin(requestBody, headers);
  }
}
