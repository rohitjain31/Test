import { IsNotEmpty } from "class-validator";
import { CODES } from '../../errors/errorCodeConstants';

export class AdminRegister {
    @IsNotEmpty({ message: CODES.EmptyUsername })
    username: string;

    @IsNotEmpty({ message: CODES.EmptyPassword })
    password: string;
}