import { CODES } from './errorCodeConstants';

const errors: { [key: string]: { code: string; message?: string; description?: string } } = {
  [CODES.InvalidBody]: {
    code: 'GLOBAL.BODY_INVALID',
    message: 'Invalid Request Parameters',
    description: 'Invalid Request Parameters'
  },
  [CODES.RequestTimeout]: {
    code: 'GLOBAL.REQUEST_TIMEOUT',
    message: 'Request is timeout',
    description: 'Request is timeout'
  },
  [CODES.EmptyAuthorization]: {
    code: 'GLOBAL.EMPTY.AUTHORIZATION_TOKEN',
    message: 'Authorization token is empty',
    description: 'Authorization token is empty'
  },
  [CODES.NotAuthorized]: {
    code: 'GLOBAL.NOT_AUTHORIZED',
    message: 'User is not authorized',
    description: 'User is not authorized'
  },
  [CODES.EmptyContentType]: {
    code: 'GLOBAL.EMPTY.CONTENT_TYPE',
    message: 'Content type is empty',
    description: 'Content type is empty'
  },
  [CODES.InvalidContentType]: {
    code: 'GLOBAL.INVALID.CONTENT_TYPE',
    message: 'Content type is invalid',
    description: 'Content type is invalid'
  },
  [CODES.EmptyURC]: {
    code: 'GLOBAL.EMPTY.URC',
    message: 'Unique reference code is empty',
    description: 'Unique reference code is empty'
  },
  [CODES.InvalidURC]: {
    code: 'GLOBAL.INVALID.URC',
    message: 'Unique reference code is invalid',
    description: 'Unique reference code is invalid'
  },
  [CODES.GenericErrorMessage]: {
    code: 'GLOBAL.INTERVAL_SERVER_ERROR',
    message: 'There is some issue. Please contact administrator',
    description: 'There is some issue. Please contact administrator'
  },
  [CODES.IncorrectPassword]: {
    code: 'GLOBAL.INCORRECT.PASSWORD',
    message: 'Password is incorrect',
    description: 'Password is incorrect'
  },
  [CODES.InvalidRegistrationHeader]: {
    code: 'GLOBAL.INVALID.REGISTRATION_HEADER',
    message: 'Registration header is invalid',
    description: 'Registration header is invalid'
  },
  [CODES.AuthTokenError]: {
    code: 'GLOBAL.ERROR.AUTH_TOKEN',
    message: 'Error in generating auth token',
    description: 'Error in generating auth token'
  },
  [CODES.InvalidJWTToken]: {
    code: 'GLOBAL.INVALID.AUTH_TOKEN',
    message: 'Auth token is invalid',
    description: 'Auth token is invalid'
  },
  [CODES.EmptyAuthToken]: {
    code: 'GLOBAL.EMPTY.AUTH_TOKEN',
    message: 'Auth token is empty',
    description: 'Auth token is empty'
  },
  [CODES.DuplicateKeyError]: {
    code: 'GLOBAL.DUPLICATE.COLLECTION_KEY',
    message: 'Duplicate key is provided in collection',
    description: 'Duplicate key is provided in collection'
  },
  [CODES.EmptyUsername]: {
    code: 'GLOBAL.EMPTY.USERNAME',
    message: 'Empty username is provided',
    description: 'Empty username is provided'
  },
  [CODES.EmptyPassword]: {
    code: 'GLOBAL.EMPTY.PASSWORD',
    message: 'Empty password is provided',
    description: 'Empty password is provided'
  }
};

export const constantErrors = Object.assign({}, errors);
