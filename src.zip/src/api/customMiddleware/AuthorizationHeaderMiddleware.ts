import * as express from 'express';
import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';
import { Container } from 'typedi';

import { env } from '../../env';
import { JWTDecode, getDataFromValidatedToken, isEmptyOrNull } from '../../lib/env';
import { Logger } from '../../lib/logger';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { Admin } from '../models/Admin';
import { isArray } from 'class-validator';

@Middleware({ type: 'before' })
export class AuthorizationHeaderMiddleware implements ExpressMiddlewareInterface {
  private log = new Logger(__filename);
  public async use(req: express.Request, res: express.Response, next: express.NextFunction): Promise<any> {
    const logMessage = 'AuthorizationHeaderMiddleware :: use';
    const authorizeHeader = (req.header('Authorization') || '').trim();
    if (!authorizeHeader) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EmptyAuthorization);
    }
    if (authorizeHeader.indexOf('Bearer') < 0) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.NotAuthorized);
    }

    const splittedToken = authorizeHeader.split(' ');
    const authToken = isArray(splittedToken) && splittedToken.length === 2 ? splittedToken[1] : '';
    if (!authToken) {
      this.log.info(`${logMessage}, Auth token is empty`);
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EmptyAuthToken);
    }

    const validatedToken = JWTDecode(authToken, env.jwt.secret);
    const validatedData: any = getDataFromValidatedToken(
      validatedToken,
      env.constants.base64EncryptionKey,
      env.constants.aesIVBase64
    );
    const username = validatedData?.username || '';
    const uniqueId = validatedData?.uniqueId || '';

    const user = await Admin.findOne({ username, uniqueId });
    if (isEmptyOrNull(user)) {
      this.log.info(`${logMessage}, User not found for usename ${username} and uniqueId ${uniqueId}`);
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.NotAuthorized);
    }

    Container.set('requestHeaders', req.headers);
    next();
  }
}
