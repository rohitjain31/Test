import * as express from 'express';
import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';
import { Container } from 'typedi';

import { CODES, HTTPCODES } from '../errors/errorCodeConstants';
import { CredError } from '../errors/CredError';

@Middleware({ type: 'before' })
export class URCHeaderMiddleware implements ExpressMiddlewareInterface {
  public use(req: express.Request, res: express.Response, next: express.NextFunction): any {
    const urc = (req.header('Unique-Reference-Code') || '').trim();
    if (!urc) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.EmptyURC);
    }
    res.setHeader('Unique-Reference-Code', urc);

    Container.set('requestHeaders', req.headers);
    next();
  }
}
