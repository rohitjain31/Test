import * as express from 'express';
import bodyParser from 'body-parser';
import { StatusCodes } from 'http-status-codes';
import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';

import { Logger } from '../../lib/logger';

@Middleware({ type: 'before' })
export class BodyParserMiddleware implements ExpressMiddlewareInterface {
    private log = new Logger(__filename);
    public use(req: express.Request, res: express.Response, next: express.NextFunction): any {
        const urc = (req.header('Unique-Reference-Code') || '').trim();
        this.log.info(`BodyParserMiddleware, urc, ${urc}`);

        bodyParser.urlencoded({ extended: true });
        (bodyParser.json({ limit: '20mb' }))(req, res, (error): void => {
            if (error?.status === StatusCodes.BAD_REQUEST && error?.type === 'entity.parse.failed') {
                res.status(StatusCodes.BAD_REQUEST);
                this.log.error(`BodyParserMiddleware, Invalid Body, urc ${urc}`);
                res.json({ errors: [{ code: 'GLOBAL.BODY_INVALID', message: error?.message }] });
                return;
            }

            if (error?.status === StatusCodes.REQUEST_TOO_LONG && error?.type === 'entity.too.large') {
                res.status(StatusCodes.BAD_REQUEST);
                this.log.error(`BodyParserMiddleware, Invalid Body, urc ${urc}`);
                res.json({ errors: [{ code: 'GLOBAL.BODY_INVALID', message: error?.message }] });
                return;
            }
            next()
        });
    }
}