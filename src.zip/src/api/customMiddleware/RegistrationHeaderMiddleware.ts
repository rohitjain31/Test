import * as express from 'express';
import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';
import { Container } from 'typedi';

import { env } from '../../env';
import { CredError } from '../errors/CredError';
import { CODES, HTTPCODES } from '../errors/errorCodeConstants';

@Middleware({ type: 'before' })
export class RegistrationHeaderMiddleware implements ExpressMiddlewareInterface {
  public use(req: express.Request, res: express.Response, next: express.NextFunction): any {
    const authorizeHeader = (req.header('Authorization') || '').trim();
    if (authorizeHeader !== env.constants.registrationHeader) {
      throw new CredError(HTTPCODES.BAD_REQUEST, CODES.InvalidRegistrationHeader);
    }

    Container.set('requestHeaders', req.headers);
    next();
  }
}
