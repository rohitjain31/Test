import 'dotenv/config';
import 'reflect-metadata';

import './loaders/iocLoader';

import { banner } from './lib/banner';
import { Logger } from './lib/logger';
import connectDB from './loaders/DBLoader';
import { winstonLoader } from './loaders/winstonLoader';

import './loaders/expressLoader';
import './loaders/homeLoader';
import './api/Scheduler/Scheduler';

const log = new Logger(__filename);

(async function initiateLoader() {
  try {
    await connectDB();
    await winstonLoader();
  } catch (error) {
    log.error('Application Crashed ', error);
  }
})();

/**
 * EXPRESS TYPESCRIPT BOILERPLATE
 * ----------------------------------------
 *
 * This is a boilerplate for Node.js Application written in TypeScript.
 * The basic layer of this app is express. For further information visit
 * the 'README.md' file.
 */
try {
  banner(log);
} catch (error: any) {
  log.error('Application Crashed ', error);
}
